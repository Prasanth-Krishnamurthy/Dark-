const express = require('express');
const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS properly to prevent "Failed to Fetch"
app.use(cors({
    origin: '*', // Allow all origins for now (adjust in production)
    methods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Middleware
app.use(express.json());

// Spam Protection: Rate Limiting
const contactLimit = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 10, // Increased to 10 for testing
    message: { error: "Too many messages sent from this IP, please try again after an hour." }
});

// Nodemailer Transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD
    }
});

// API Route: Send Contact Message
// Endpoint changed to /send as per requirement
app.post('/send', contactLimit, async (req, res) => {
    const { user_name, user_email, message, honeypot } = req.body;

    // Spam Protection: Honeypot Check
    if (honeypot) {
        return res.status(400).json({ error: "Spam detected." });
    }

    // Server-side Validation
    if (!user_name || !user_email || !message) {
        return res.status(400).json({ error: "All fields are required." });
    }

    // Email Options
    const mailOptions = {
        from: `"${user_name}" <${process.env.GMAIL_USER}>`,
        to: 'prasanthkrishnamurthy2312@gmail.com',
        replyTo: user_email,
        subject: `New Portfolio Message from ${user_name}`,
        text: `Name: ${user_name}\nEmail: ${user_email}\n\nMessage:\n${message}`,
        html: `<h3>New Message</h3><p><b>Name:</b> ${user_name}</p><p><b>Email:</b> ${user_email}</p><p><b>Message:</b></p><p>${message}</p>`
    };

    try {
        await transporter.sendMail(mailOptions);
        res.status(200).json({ success: "Message sent! I'll get back to you soon." });
    } catch (error) {
        console.error('Nodemailer Error:', error);
        res.status(500).json({ error: "Failed to send. Try again later." });
    }
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
