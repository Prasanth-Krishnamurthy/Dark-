// Theme Toggle System
const themeToggle = document.getElementById('theme-toggle');
const body = document.body;

themeToggle.addEventListener('click', () => {
    const currentTheme = body.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    body.setAttribute('data-theme', newTheme);
    themeToggle.textContent = newTheme === 'light' ? '🌙' : '☀️';
});

// Typing Animation
const typingElement = document.querySelector('.typing-text');
const roles = ["AI & Data Science Student", "Aspiring Data Analyst", "Problem Solver"];
let roleIndex = 0;
let charIndex = 0;
let isDeleting = false;

function type() {
    const currentRole = roles[roleIndex];

    if (isDeleting) {
        typingElement.textContent = currentRole.substring(0, charIndex - 1);
        charIndex--;
    } else {
        typingElement.textContent = currentRole.substring(0, charIndex + 1);
        charIndex++;
    }

    let typeSpeed = isDeleting ? 100 : 200;

    if (!isDeleting && charIndex === currentRole.length) {
        isDeleting = true;
        typeSpeed = 2000; // Pause at end
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        roleIndex = (roleIndex + 1) % roles.length;
        typeSpeed = 500;
    }

    setTimeout(type, typeSpeed);
}

document.addEventListener('DOMContentLoaded', type);


// Reveal on Scroll with Stagger
const revealItems = document.querySelectorAll('.reveal');

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');

            // Special handling for skill bars
            if (entry.target.id === 'skills') {
                const bars = entry.target.querySelectorAll('.skill-progress');
                bars.forEach(bar => {
                    bar.style.width = bar.getAttribute('data-width');
                });
            }
        }
    });
}, { threshold: 0.1 });

revealItems.forEach(item => revealObserver.observe(item));

// Contact Form Handling (Backend: Express + Nodemailer)
const contactForm = document.getElementById('portfolio-contact');
const statusMessage = document.getElementById('contact-status');

// Helper to show status
function showStatus(text, type) {
    statusMessage.textContent = text;
    statusMessage.className = `status-message ${type}`;
    statusMessage.style.display = 'block';

    // Hide after 5 seconds
    setTimeout(() => {
        statusMessage.style.display = 'none';
    }, 5000);
}

if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const submitBtn = contactForm.querySelector('button');

        // Validation
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const message = document.getElementById('message').value.trim();
        const honeypot = document.getElementById('honeypot').value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!name || !email || !message) {
            showStatus('Please fill in all fields.', 'error');
            return;
        }

        if (!emailRegex.test(email)) {
            showStatus('Please enter a valid email address.', 'error');
            return;
        }

        // Show loading state
        submitBtn.classList.add('btn-loading');

        try {
            // FULL BACKEND URL (Vital for GitHub Pages / Netlify)
            // Replace with your Render/Vercel URL after deployment
            const BACKEND_URL = 'http://localhost:3000/send';

            const response = await fetch(BACKEND_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_name: name,
                    user_email: email,
                    message: message,
                    honeypot: honeypot // Bot protection
                }),
            });

            const result = await response.json();

            if (response.ok) {
                showStatus(result.success, 'success');
                contactForm.reset();
            } else {
                throw new Error(result.error || 'Internal Server Error');
            }
        } catch (error) {
            console.error('Submission Error:', error);

            // Custom message for "Failed to Fetch" (CORS or server down)
            if (error.message === 'Failed to fetch') {
                showStatus('Connection failed. Make sure the backend server is running!', 'error');
            } else {
                showStatus(error.message, 'error');
            }
        } finally {
            submitBtn.classList.remove('btn-loading');
        }
    });
}

// Navbar Scroll Effect
window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    if (window.scrollY > 50) {
        header.style.padding = '12px 0';
        header.style.background = 'rgba(10, 15, 30, 0.9)';
    } else {
        header.style.padding = '20px 0';
        header.style.background = 'var(--glass-bg)';
    }
});
